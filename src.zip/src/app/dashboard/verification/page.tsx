import DataTable from "@/components/DataTable";
import { MOCK_VERIFICATION_ITEMS } from "@/lib/mockAgentric";

const VERIFICATION_COLUMNS = [
  {
    key: "id",
    header: "ID",
    render: (row: (typeof MOCK_VERIFICATION_ITEMS)[0]) => (
      <span className="font-mono text-zinc-300 text-xs">{row.id}</span>
    ),
  },
  {
    key: "epoch",
    header: "Epoch",
    render: (row: (typeof MOCK_VERIFICATION_ITEMS)[0]) => (
      <span className="font-mono text-zinc-200">{row.epoch}</span>
    ),
  },
  {
    key: "status",
    header: "Status",
    render: (row: (typeof MOCK_VERIFICATION_ITEMS)[0]) => (
      <span className="text-emerald-500">{row.status}</span>
    ),
  },
  {
    key: "attestedAt",
    header: "Attested at",
    render: (row: (typeof MOCK_VERIFICATION_ITEMS)[0]) => (
      <span className="text-muted font-mono text-xs">
        {new Date(row.attestedAt).toISOString().replace("T", " ").slice(0, 19)}Z
      </span>
    ),
  },
];

export default function VerificationPage() {
  return (
    <div className="p-6 max-w-6xl">
      <h1 className="text-xl font-semibold text-zinc-100 tracking-tight">
        Verification
      </h1>
      <p className="mt-1 text-sm text-muted">
        Verification state and attestations. Read-only.
      </p>

      <section className="mt-6">
        <h2 className="text-sm font-medium text-muted uppercase tracking-wider mb-3">
          Attestations
        </h2>
        <DataTable
          columns={VERIFICATION_COLUMNS}
          data={MOCK_VERIFICATION_ITEMS}
          keyField="id"
        />
      </section>

      <section className="mt-6 border border-border bg-surface-800 rounded p-4">
        <h2 className="text-sm font-medium text-muted uppercase tracking-wider mb-2">
          About verification
        </h2>
        <p className="text-sm text-zinc-400">
          Attestations are published per epoch. Execution paths and outcomes
          can be verified on-chain against these records. No trust in the
          control plane is required for verification.
        </p>
      </section>
    </div>
  );
}
