import DataTable from "@/components/DataTable";
import { MOCK_AGENTS } from "@/lib/mockAgentric";
import type { Agent } from "@/lib/mockAgentric";

const AGENT_COLUMNS = [
  {
    key: "id",
    header: "ID",
    render: (row: Agent) => (
      <span className="font-mono text-zinc-300 text-xs">{row.id}</span>
    ),
  },
  {
    key: "name",
    header: "Name",
    render: (row: Agent) => (
      <span className="text-zinc-200 font-medium">{row.name}</span>
    ),
  },
  {
    key: "status",
    header: "Status",
    render: (row: Agent) => (
      <span
        className={
          row.status === "active"
            ? "text-emerald-500"
            : row.status === "paused"
              ? "text-amber-500"
              : row.status === "error"
                ? "text-red-500"
                : "text-muted"
        }
      >
        {row.status}
      </span>
    ),
  },
  {
    key: "chainId",
    header: "Chain",
    render: (row: Agent) => (
      <span className="font-mono text-muted text-xs">{row.chainId}</span>
    ),
  },
  {
    key: "lastSeen",
    header: "Last seen",
    render: (row: Agent) => (
      <span className="text-muted font-mono text-xs">
        {row.lastSeen === "—" ? "—" : new Date(row.lastSeen).toISOString().slice(0, 19) + "Z"}
      </span>
    ),
  },
  {
    key: "executionCount",
    header: "Executions",
    render: (row: Agent) => (
      <span className="text-zinc-400">{row.executionCount}</span>
    ),
  },
];

export default function AgentsPage() {
  return (
    <div className="p-6 max-w-6xl">
      <h1 className="text-xl font-semibold text-zinc-100 tracking-tight">
        Agents
      </h1>
      <p className="mt-1 text-sm text-muted">
        Registered agents and their configuration. Read-only.
      </p>

      <section className="mt-6">
        <DataTable
          columns={AGENT_COLUMNS}
          data={MOCK_AGENTS}
          keyField="id"
        />
      </section>
    </div>
  );
}
