export default function SettingsPage() {
  return (
    <div className="p-6 max-w-6xl">
      <h1 className="text-xl font-semibold text-zinc-100 tracking-tight">
        Settings
      </h1>
      <p className="mt-1 text-sm text-muted">
        Control plane configuration. Placeholder for future options.
      </p>

      <section className="mt-6 border border-border bg-surface-800 rounded p-6">
        <h2 className="text-sm font-medium text-muted uppercase tracking-wider mb-3">
          General
        </h2>
        <p className="text-sm text-zinc-400">
          No configurable settings in this release. The dashboard is read-only
          and driven by mock data. Backend integration and user preferences
          will be added in a future release.
        </p>
      </section>

      <section className="mt-6 border border-border bg-surface-800 rounded p-6">
        <h2 className="text-sm font-medium text-muted uppercase tracking-wider mb-3">
          About
        </h2>
        <p className="text-sm text-zinc-400">
          Agentric Control Plane — open-source, non-custodial. No keys or
          funds are held by this application.
        </p>
      </section>
    </div>
  );
}
