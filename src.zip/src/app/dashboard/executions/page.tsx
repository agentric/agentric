import DataTable from "@/components/DataTable";
import ExecutionTimeline from "@/components/ExecutionTimeline";
import { MOCK_EXECUTIONS } from "@/lib/mockAgentric";
import type { Execution } from "@/lib/mockAgentric";

const EXECUTION_COLUMNS = [
  {
    key: "id",
    header: "Execution",
    render: (row: Execution) => (
      <span className="font-mono text-zinc-300">{row.id}</span>
    ),
  },
  {
    key: "agentName",
    header: "Agent",
    render: (row: Execution) => (
      <span className="text-zinc-300">{row.agentName}</span>
    ),
  },
  {
    key: "status",
    header: "Status",
    render: (row: Execution) => (
      <span
        className={
          row.status === "completed"
            ? "text-emerald-500"
            : row.status === "failed"
              ? "text-red-500"
              : row.status === "running"
                ? "text-blue-500"
                : "text-amber-500"
        }
      >
        {row.status}
      </span>
    ),
  },
  {
    key: "startedAt",
    header: "Started",
    render: (row: Execution) => (
      <span className="text-muted font-mono text-xs">
        {new Date(row.startedAt).toISOString().replace("T", " ").slice(0, 19)}Z
      </span>
    ),
  },
  {
    key: "completedAt",
    header: "Completed",
    render: (row: Execution) => (
      <span className="text-muted font-mono text-xs">
        {row.completedAt
          ? new Date(row.completedAt).toISOString().replace("T", " ").slice(0, 19) + "Z"
          : "—"}
      </span>
    ),
  },
  {
    key: "route",
    header: "Route",
    render: (row: Execution) => (
      <span className="font-mono text-xs text-zinc-400">
        {row.route.length ? row.route.join(" → ") : "—"}
      </span>
    ),
  },
  {
    key: "txHash",
    header: "Tx",
    render: (row: Execution) => (
      <span className="font-mono text-xs text-muted">
        {row.txHash ?? "—"}
      </span>
    ),
  },
];

export default function ExecutionsPage() {
  return (
    <div className="p-6 max-w-6xl">
      <h1 className="text-xl font-semibold text-zinc-100 tracking-tight">
        Executions
      </h1>
      <p className="mt-1 text-sm text-muted">
        Execution history and timeline. Read-only.
      </p>

      <section className="mt-6">
        <h2 className="text-sm font-medium text-muted uppercase tracking-wider mb-3">
          Timeline
        </h2>
        <ExecutionTimeline executions={MOCK_EXECUTIONS} />
      </section>

      <section className="mt-8">
        <h2 className="text-sm font-medium text-muted uppercase tracking-wider mb-3">
          All executions
        </h2>
        <DataTable
          columns={EXECUTION_COLUMNS}
          data={MOCK_EXECUTIONS}
          keyField="id"
        />
      </section>
    </div>
  );
}
