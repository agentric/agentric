import DataTable from "@/components/DataTable";
import ExecutionTimeline from "@/components/ExecutionTimeline";
import StatusTile from "@/components/StatusTile";
import {
  MOCK_EXECUTIONS,
  MOCK_STATUS_FLAGS,
  MOCK_SYSTEM_NOTES,
} from "@/lib/mockAgentric";
import type { Execution } from "@/lib/mockAgentric";

const EXECUTION_COLUMNS = [
  {
    key: "id",
    header: "Execution",
    render: (row: Execution) => (
      <span className="font-mono text-zinc-300">{row.id}</span>
    ),
  },
  {
    key: "agentName",
    header: "Agent",
    render: (row: Execution) => (
      <span className="text-zinc-300">{row.agentName}</span>
    ),
  },
  {
    key: "status",
    header: "Status",
    render: (row: Execution) => (
      <span
        className={
          row.status === "completed"
            ? "text-emerald-500"
            : row.status === "failed"
              ? "text-red-500"
              : row.status === "running"
                ? "text-blue-500"
                : "text-amber-500"
        }
      >
        {row.status}
      </span>
    ),
  },
  {
    key: "startedAt",
    header: "Started",
    render: (row: Execution) => (
      <span className="text-muted font-mono text-xs">
        {new Date(row.startedAt).toISOString().replace("T", " ").slice(0, 19)}Z
      </span>
    ),
  },
  {
    key: "route",
    header: "Route",
    render: (row: Execution) => (
      <span className="font-mono text-xs text-zinc-400">
        {row.route.length ? row.route.join(" → ") : "—"}
      </span>
    ),
  },
];

function formatNoteTime(iso: string) {
  return new Date(iso).toISOString().replace("T", " ").slice(0, 19);
}

export default function DashboardOverviewPage() {
  return (
    <div className="p-6 max-w-6xl">
      <h1 className="text-xl font-semibold text-zinc-100 tracking-tight">
        Overview
      </h1>
      <p className="mt-1 text-sm text-muted">
        Control plane status and recent activity.
      </p>

      <section className="mt-6">
        <h2 className="text-sm font-medium text-muted uppercase tracking-wider mb-3">
          Status
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {MOCK_STATUS_FLAGS.map((flag) => (
            <StatusTile key={flag.id} {...flag} />
          ))}
        </div>
      </section>

      <section className="mt-8">
        <h2 className="text-sm font-medium text-muted uppercase tracking-wider mb-3">
          Recent executions
        </h2>
        <DataTable
          columns={EXECUTION_COLUMNS}
          data={MOCK_EXECUTIONS}
          keyField="id"
        />
      </section>

      <section className="mt-8">
        <h2 className="text-sm font-medium text-muted uppercase tracking-wider mb-3">
          System notes
        </h2>
        <div className="border border-border bg-surface-800 rounded overflow-hidden">
          <table>
            <thead>
              <tr className="bg-surface-700">
                <th>Time</th>
                <th>Message</th>
                <th>Level</th>
              </tr>
            </thead>
            <tbody>
              {MOCK_SYSTEM_NOTES.map((note) => (
                <tr
                  key={note.id}
                  className="bg-surface-800 hover:bg-surface-700 border-t border-border"
                >
                  <td className="text-xs font-mono text-muted">
                    {formatNoteTime(note.timestamp)}Z
                  </td>
                  <td className="text-sm text-zinc-300">{note.message}</td>
                  <td>
                    <span
                      className={
                        note.level === "error"
                          ? "text-red-500"
                          : note.level === "warn"
                            ? "text-amber-500"
                            : "text-muted"
                      }
                    >
                      {note.level}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
