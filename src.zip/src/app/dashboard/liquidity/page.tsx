import RouteGraph from "@/components/RouteGraph";

export default function LiquidityPage() {
  return (
    <div className="p-6 max-w-6xl">
      <h1 className="text-xl font-semibold text-zinc-100 tracking-tight">
        Liquidity
      </h1>
      <p className="mt-1 text-sm text-muted">
        Liquidity and routing configuration. Read-only.
      </p>

      <section className="mt-6">
        <h2 className="text-sm font-medium text-muted uppercase tracking-wider mb-3">
          Configured routes
        </h2>
        <RouteGraph />
      </section>

      <section className="mt-6 border border-border bg-surface-800 rounded p-4">
        <h2 className="text-sm font-medium text-muted uppercase tracking-wider mb-2">
          Notes
        </h2>
        <p className="text-sm text-zinc-400">
          Route table reflects allowed paths for agent execution. No custody;
          agents operate against user-provided liquidity parameters. Backend
          integration for live config is planned.
        </p>
      </section>
    </div>
  );
}
