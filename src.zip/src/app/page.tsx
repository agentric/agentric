"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect } from "react";

export default function LandingPage() {
  const router = useRouter();

  const goToDashboard = useCallback(() => {
    router.push("/dashboard");
  }, [router]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Enter") {
        e.preventDefault();
        goToDashboard();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [goToDashboard]);

  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-4">
      <h1 className="text-3xl font-semibold tracking-tight text-zinc-100">
        Agentric
      </h1>
      <p className="mt-3 text-zinc-500 text-center max-w-md">
        Secure, non-custodial execution of on-chain agents.
      </p>
      <button
        type="button"
        onClick={goToDashboard}
        className="mt-8 px-5 py-2.5 border border-zinc-600 text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100 transition-colors rounded"
      >
        Enter
      </button>
    </main>
  );
}
