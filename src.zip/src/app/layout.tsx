import type { Metadata } from "next";
import "@/styles/globals.css";

export const metadata: Metadata = {
  title: "Agentric",
  description: "Secure, non-custodial execution of on-chain agents.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="bg-[#0f0f11] text-zinc-200">
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
