"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const NAV_ITEMS = [
  { href: "/dashboard", label: "Overview" },
  { href: "/dashboard/agents", label: "Agents" },
  { href: "/dashboard/executions", label: "Executions" },
  { href: "/dashboard/liquidity", label: "Liquidity" },
  { href: "/dashboard/verification", label: "Verification" },
  { href: "/dashboard/settings", label: "Settings" },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-52 shrink-0 border-r border-border bg-surface-800 flex flex-col">
      <div className="p-4 border-b border-border">
        <Link href="/" className="text-sm font-medium text-zinc-200 hover:text-zinc-100">
          Agentric
        </Link>
        <p className="mt-0.5 text-xs text-muted">Control plane</p>
      </div>
      <nav className="flex-1 p-3">
        <ul className="space-y-0.5">
          {NAV_ITEMS.map(({ href, label }) => {
            const isActive = pathname === href;
            return (
              <li key={href}>
                <Link
                  href={href}
                  className={`block px-3 py-2 text-sm rounded ${
                    isActive
                      ? "bg-surface-600 text-zinc-100"
                      : "text-muted hover:bg-surface-600 hover:text-zinc-200"
                  }`}
                >
                  {label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </aside>
  );
}
