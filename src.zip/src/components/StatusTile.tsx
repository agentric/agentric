import { StatusFlag } from "@/lib/mockAgentric";

const STATUS_STYLES: Record<StatusFlag["status"], string> = {
  ok: "text-emerald-500",
  warn: "text-amber-500",
  error: "text-red-500",
};

export default function StatusTile({ label, value, status }: StatusFlag) {
  return (
    <div className="border border-border bg-surface-700 rounded p-4">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs text-muted uppercase tracking-wider">{label}</span>
        <span className={`text-xs font-medium ${STATUS_STYLES[status]}`}>
          {status}
        </span>
      </div>
      <p className="mt-2 text-sm text-zinc-200 font-mono">{value}</p>
    </div>
  );
}
