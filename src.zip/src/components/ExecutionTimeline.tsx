import { Execution } from "@/lib/mockAgentric";

const STATUS_COLORS: Record<Execution["status"], string> = {
  completed: "text-emerald-500",
  failed: "text-red-500",
  pending: "text-amber-500",
  running: "text-blue-500",
};

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString("en-US", {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export default function ExecutionTimeline({ executions }: { executions: Execution[] }) {
  return (
    <div className="space-y-3">
      {executions.map((ex) => (
        <div
          key={ex.id}
          className="border border-border bg-surface-700 rounded p-3 flex items-center justify-between gap-4"
        >
          <div className="min-w-0">
            <span className="text-xs text-muted font-mono">{ex.id}</span>
            <p className="text-sm text-zinc-200 mt-0.5 truncate">
              {ex.agentName} — {ex.route.length ? ex.route.join(" → ") : "—"}
            </p>
          </div>
          <div className="shrink-0 flex items-center gap-3">
            <span className={`text-xs font-medium ${STATUS_COLORS[ex.status]}`}>
              {ex.status}
            </span>
            <span className="text-xs text-muted font-mono">
              {formatTime(ex.startedAt)}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}
