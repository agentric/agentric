import { MOCK_ROUTES } from "@/lib/mockAgentric";

/**
 * Read-only route summary. No chart library; simple table of from → to and hops.
 */
export default function RouteGraph() {
  return (
    <div className="border border-border rounded overflow-hidden">
      <table>
        <thead>
          <tr className="bg-surface-700">
            <th>From</th>
            <th>To</th>
            <th>Hops</th>
          </tr>
        </thead>
        <tbody>
          {MOCK_ROUTES.map((r, i) => (
            <tr key={i} className="bg-surface-800 hover:bg-surface-700">
              <td className="text-sm font-mono text-zinc-300">{r.from}</td>
              <td className="text-sm font-mono text-zinc-300">{r.to}</td>
              <td className="text-sm text-muted">{r.hops}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
