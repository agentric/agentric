/**
 * Mock data for the Agentric Control Plane.
 * No backend; all data is static for UI development.
 */

export type AgentStatus = "active" | "paused" | "pending" | "error";

export interface Agent {
  id: string;
  name: string;
  status: AgentStatus;
  chainId: string;
  lastSeen: string;
  executionCount: number;
}

export type ExecutionStatus = "completed" | "failed" | "pending" | "running";

export interface Execution {
  id: string;
  agentId: string;
  agentName: string;
  status: ExecutionStatus;
  startedAt: string;
  completedAt: string | null;
  route: string[];
  txHash: string | null;
}

export interface StatusFlag {
  id: string;
  label: string;
  value: string;
  status: "ok" | "warn" | "error";
}

export interface SystemNote {
  id: string;
  timestamp: string;
  message: string;
  level: "info" | "warn" | "error";
}

export const MOCK_AGENTS: Agent[] = [
  {
    id: "agt-001",
    name: "router-alpha",
    status: "active",
    chainId: "1",
    lastSeen: "2025-02-03T14:32:00Z",
    executionCount: 1247,
  },
  {
    id: "agt-002",
    name: "router-beta",
    status: "active",
    chainId: "1",
    lastSeen: "2025-02-03T14:31:58Z",
    executionCount: 892,
  },
  {
    id: "agt-003",
    name: "relay-gamma",
    status: "paused",
    chainId: "137",
    lastSeen: "2025-02-03T12:00:00Z",
    executionCount: 312,
  },
  {
    id: "agt-004",
    name: "verifier-delta",
    status: "pending",
    chainId: "1",
    lastSeen: "—",
    executionCount: 0,
  },
];

export const MOCK_EXECUTIONS: Execution[] = [
  {
    id: "ex-1001",
    agentId: "agt-001",
    agentName: "router-alpha",
    status: "completed",
    startedAt: "2025-02-03T14:31:45Z",
    completedAt: "2025-02-03T14:31:52Z",
    route: ["USDC", "WETH", "DAI"],
    txHash: "0x7a3f…2e1c",
  },
  {
    id: "ex-1002",
    agentId: "agt-002",
    agentName: "router-beta",
    status: "completed",
    startedAt: "2025-02-03T14:31:30Z",
    completedAt: "2025-02-03T14:31:38Z",
    route: ["DAI", "USDC"],
    txHash: "0x9b2c…4d3a",
  },
  {
    id: "ex-1003",
    agentId: "agt-001",
    agentName: "router-alpha",
    status: "failed",
    startedAt: "2025-02-03T14:30:12Z",
    completedAt: "2025-02-03T14:30:15Z",
    route: ["WETH", "USDT"],
    txHash: null,
  },
  {
    id: "ex-1004",
    agentId: "agt-001",
    agentName: "router-alpha",
    status: "running",
    startedAt: "2025-02-03T14:32:01Z",
    completedAt: null,
    route: ["USDC", "WETH"],
    txHash: null,
  },
  {
    id: "ex-1005",
    agentId: "agt-002",
    agentName: "router-beta",
    status: "pending",
    startedAt: "2025-02-03T14:32:05Z",
    completedAt: null,
    route: [],
    txHash: null,
  },
];

export const MOCK_STATUS_FLAGS: StatusFlag[] = [
  { id: "sf-1", label: "Control plane", value: "operational", status: "ok" },
  { id: "sf-2", label: "Agent registry", value: "4 registered", status: "ok" },
  { id: "sf-3", label: "Verification service", value: "synced", status: "ok" },
  { id: "sf-4", label: "Last attestation", value: "2025-02-03T14:00:00Z", status: "warn" },
];

export const MOCK_SYSTEM_NOTES: SystemNote[] = [
  {
    id: "sn-1",
    timestamp: "2025-02-03T14:32:00Z",
    message: "Execution ex-1004 started on router-alpha.",
    level: "info",
  },
  {
    id: "sn-2",
    timestamp: "2025-02-03T14:31:52Z",
    message: "Execution ex-1001 completed. Route: USDC → WETH → DAI.",
    level: "info",
  },
  {
    id: "sn-3",
    timestamp: "2025-02-03T14:30:15Z",
    message: "Execution ex-1003 failed: slippage exceeded.",
    level: "warn",
  },
  {
    id: "sn-4",
    timestamp: "2025-02-03T14:00:00Z",
    message: "Verification attestation published for epoch 2847.",
    level: "info",
  },
];

export const MOCK_ROUTES: { from: string; to: string; hops: number }[] = [
  { from: "USDC", to: "DAI", hops: 2 },
  { from: "DAI", to: "USDC", hops: 1 },
  { from: "WETH", to: "USDT", hops: 2 },
  { from: "USDC", to: "WETH", hops: 1 },
];

export const MOCK_VERIFICATION_ITEMS: { id: string; epoch: string; status: string; attestedAt: string }[] = [
  { id: "v-1", epoch: "2847", status: "attested", attestedAt: "2025-02-03T14:00:00Z" },
  { id: "v-2", epoch: "2846", status: "attested", attestedAt: "2025-02-03T12:00:00Z" },
  { id: "v-3", epoch: "2845", status: "attested", attestedAt: "2025-02-03T10:00:00Z" },
];
